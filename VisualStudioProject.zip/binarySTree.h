
#ifndef BINARYSTREE_H
#define BINARYSTREE_H

#include <iostream>
#include <vector>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* leftNext;
    Node* rightNext;

    Node(int value) : data(value), leftNext(nullptr), rightNext(nullptr) {}
};

class BinarySearchTree {
private:
    Node* root;

    void insert(Node*& current, int value);
    void preOrder(Node* current, vector<int>& result);
    void inOrder(Node* current, vector<int>& result);
    void postOrder(Node* current, vector<int>& result);

public:
    BinarySearchTree();
    void insert(int value);
    vector<int> preOrderTraversal();
    vector<int> inOrderTraversal();
    vector<int> postOrderTraversal();
};

#endif
