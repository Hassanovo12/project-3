
#include "binarySTree.h"

// Constructor
BinarySearchTree::BinarySearchTree() : root(nullptr) {}

// Insert a value into the BST
void BinarySearchTree::insert(Node*& current, int value) {
    if (!current) {
        current = new Node(value);
    } else if (value < current->data) {
        insert(current->leftNext, value);
    } else {
        insert(current->rightNext, value);
    }
}

// Public insert function
void BinarySearchTree::insert(int value) {
    insert(root, value);
}

// Pre-order traversal
void BinarySearchTree::preOrder(Node* current, vector<int>& result) {
    if (current) {
        result.push_back(current->data);
        preOrder(current->leftNext, result);
        preOrder(current->rightNext, result);
    }
}

// In-order traversal
void BinarySearchTree::inOrder(Node* current, vector<int>& result) {
    if (current) {
        inOrder(current->leftNext, result);
        result.push_back(current->data);
        inOrder(current->rightNext, result);
    }
}

// Post-order traversal
void BinarySearchTree::postOrder(Node* current, vector<int>& result) {
    if (current) {
        postOrder(current->leftNext, result);
        postOrder(current->rightNext, result);
        result.push_back(current->data);
    }
}

// Public traversal functions
vector<int> BinarySearchTree::preOrderTraversal() {
    vector<int> result;
    preOrder(root, result);
    return result;
}

vector<int> BinarySearchTree::inOrderTraversal() {
    vector<int> result;
    inOrder(root, result);
    return result;
}

vector<int> BinarySearchTree::postOrderTraversal() {
    vector<int> result;
    postOrder(root, result);
    return result;
}
