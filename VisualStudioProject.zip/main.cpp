
#include "binarySTree.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(time(0));
    BinarySearchTree bst;

    // Generate 35 random numbers and insert them into the tree
    vector<int> numbers;
    for (int i = 0; i < 35; ++i) {
        int num = rand() % 100;
        numbers.push_back(num);
        bst.insert(num);
    }

    // Display the numbers in their original order
    cout << "Original numbers:" << endl;
    for (int num : numbers) {
        cout << num << " ";
    }
    cout << endl << endl;

    // Perform and display traversals
    vector<int> preOrder = bst.preOrderTraversal();
    vector<int> inOrder = bst.inOrderTraversal();
    vector<int> postOrder = bst.postOrderTraversal();

    cout << "Pre-Order Traversal:" << endl;
    for (int num : preOrder) {
        cout << num << " ";
    }
    cout << endl << endl;

    cout << "In-Order Traversal:" << endl;
    for (int num : inOrder) {
        cout << num << " ";
    }
    cout << endl << endl;

    cout << "Post-Order Traversal:" << endl;
    for (int num : postOrder) {
        cout << num << " ";
    }
    cout << endl << endl;

    return 0;
}
