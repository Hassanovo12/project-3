
Project Title: Binary Search Tree Implementation

Description:
This project implements a Binary Search Tree (BST) in C++. It generates 35 random natural numbers less than 100,
inserts them into the BST, and performs pre-order, in-order, and post-order traversals.

Files:
1. binarySTree.h - Header file containing the BST class and Node structure.
2. binarySTree.cpp - Implementation of the BST methods.
3. main.cpp - Main program file to test the BST implementation.
4. readme.txt - This file.

Instructions:
1. Open the project in Visual Studio.
2. Add the files binarySTree.h, binarySTree.cpp, and main.cpp to the project.
3. Compile and run the program to see the traversal results.
